
function flipPage() {
  document.querySelector('.book').classList.toggle('flipped');
}
